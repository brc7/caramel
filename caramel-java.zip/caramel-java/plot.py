import argparse
import os
import numpy as np
import matplotlib.pyplot as plt

if __name__ == '__main__':

	parser = argparse.ArgumentParser(description='Generate plots from statistics file.')
	parser.add_argument('statfile', metavar='stat_file', type=str, help='Path to csf_stats.csv.')
	args = parser.parse_args()

	if not os.path.isfile(args.statfile):
		print(f"Error: {args.statfile} is not a valid file.")
		sys.exit()


	# dimension, csf_size_bits, csf_file_size_bits,
	# bloom_size_bits, bloom_file_size_bits,
	# bits_per_key, bits_per_key_with_overhead, entropy,
	# num_values, num_unique_values, max, min, top1,
	# top1_prob, top2, top2_prob, best_codec\n'

	X = np.loadtxt(args.statfile, delimiter=',', skiprows=1, usecols=list(range(15)))
	if len(X.shape) == 1:
		X = X.reshape([1,-1])
	inds = X[:,0].argsort()
	X = X[inds[::-1],:]
	num_dimensions = X.shape[0]

	plt.plot(X[:,0], X[:,7], 'k--', label = "Zero-order entropy")
	plt.plot(X[:,0], X[:,1]/X[:,8], 'r-', label = "CSF Size")
	plt.plot(X[:,0], X[:,2]/X[:,8], color='orange', label = "CSF Size + Java overhead")
	plt.plot(X[:,0], np.log2(X[:,9]), 'g--', label = "Entropy of uniform distribution")

	print(f'CSF representation: {np.sum(X[:,2]) / (8.0 * 1e6):.2f} MB. Original: {X[0,8] * X.shape[0] * 32 / (8.0 * 1e6):.2f} MB (32-bit ints) {X[0,8] * X.shape[0] * 64 / (8.0 * 1e6):.2f} (64-bit ints)')
	print(f'sum H0 = {np.sum(X[:,7]):.4f}')

	plt.xlabel("Feature ID", fontsize = 18)
	plt.ylabel("space / key (Bits)", fontsize = 18)
	plt.grid()
	plt.legend(fontsize=12)
	plt.title(args.statfile, fontsize = 22)
	plt.show()
