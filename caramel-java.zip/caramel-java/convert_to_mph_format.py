import numpy as np
import sys
# Converts a npy file and a set of keys to indeed MPH ingestion format
# If no keys provided, then we use strings from '0' to 'N'

# Call: Python3 convert_to_mph_format.py [input npy file] [output TSV file] [keys]
if len(sys.argv) < 3:
    print("Python3 convert_to_mph_format.py [input npy file] [output TSV file] [optional keys]")
    sys.exit()

X = np.load(sys.argv[1])
N, d = X.shape
with open(sys.argv[2], 'wt') as f:
    if len(sys.argv) > 3:
        keys = open(sys.argv[3], 'rt')
    else:
        keys = range(N)
    for row, key in zip(X, keys):
        csv_string = ','.join([f'{x:d}' for x in row])
        f.write(str(key) + '\t' + csv_string)
        f.write('\n')

