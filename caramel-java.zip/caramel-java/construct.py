import argparse
import subprocess
import numpy as np
import pathlib
import os
import sys
import re


def csf_utility_cmd(key_filename, value_filename, csf_filename, extra_flags = None):
	# key_filename: text file containing set of N newline-separated keys
	# value_filename: binary file containing a list of N unsigned long (8-byte) integers
	# csf_filename: path to write the csf file
	# extra_flags: extra flag options to pass to the Java CSF construction tool (e.g. codec type)
	java_classpath = "./java-caramel/target/java-caramel-1.0-SNAPSHOT.jar"
	jar_name = "com.randorithms.app.App"
	cmd = ["java", "-cp", java_classpath, jar_name]
	if extra_flags is not None:
		cmd += extra_flags
	cmd += ["-v", value_filename, csf_filename, key_filename]
	return cmd


def wc_utility_cmd(csf_filename):
	return ["wc", "-c", csf_filename]


def parse_csf_size(cmd_output):
	results = re.search('\\d+ bits', cmd_output).group()
	try:
		return int(results.split()[0])
	except:
		return -1


def parse_wc_size(cmd_output):
	try:
		return int(cmd_output.split()[0])
	except:
		return -1


def get_data_filenames(directory_path):
	return [os.path.join(directory_path, f) for f in os.listdir(directory_path)
		if (os.path.isfile(os.path.join(directory_path, f)) and os.path.splitext(f)[-1] == '.bin')]


if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='Run an experiment with the CSF java tool.')
	parser.add_argument('directory', metavar='CSF directory', type=str, help='Directory containing prepared CSF inputs.')
	parser.add_argument('-v', '--verbose', action='count', default=0, help='Verbosity level (e.g. vv = level 2). 0 = no output, 1 = CSV of best codecs, 2 = CSV of all codecs, 3 = show java tool output.')
	parser.add_argument('-c', '--codecs', type=str, default=['HUFFMAN'], choices=('ALL', 'UNARY', 'BINARY', 'GAMMA', 'HUFFMAN', 'LLHUFFMAN'), nargs='+', help='Type of codec to use. If ALL, then we try all codecs (except the UNARY) and select the best one.')
	parser.add_argument('-l', '--ll_huffman_limit', type=int, default=None, help='Depth limit for the LLHUFFMAN codec.')
	args = parser.parse_args()

	if not os.path.isdir(args.directory):
		print(f"Error: {args.directory} is not a valid directory.")
		sys.exit()

	data_files = get_data_filenames(args.directory)
	get_data_dim = lambda x:int(pathlib.Path(x).stem.split('_')[-1])
	data_dim_pairs = [[f, get_data_dim(f)] for f in data_files]

	data_dim_pairs = sorted(data_dim_pairs, key=lambda x:x[1])

	if args.verbose >= 1:
		print(f'codec, dimension, entropy, bits / key, bits / key (with Java overhead)')

	# This is necessary because we can no longer compute entropy or statistics
	# on the version of the integer list that has been pre-filtered via bloom filter
	# We need to either input the data matrix, or write the stats during preprocessing.
	preprocess_stat_dict = {}
	with open(os.path.join(args.directory, 'csf_preprocess_stats.csv'), 'rt') as stat_file:
		stat_file.readline()
		for line in stat_file:
			dim, stats = line.strip().split(',', 1)
			preprocess_stat_dict[int(dim)] = stats

	for _, dim in data_dim_pairs:
		if dim not in preprocess_stat_dict:
			preprocess_stat_dict[dim] = '-1,-1,-1,-1,-1,-1,-1,-1,-1,-1'
			print(f'Warning: dimension {dim} was not in preprocessed stats file! Results may be incorrect.')

	stat_header = 'dimension, csf_size_bits, csf_file_size_bits, bloom_size_bits, bloom_file_size_bits, bits_per_key, bits_per_key_with_overhead, entropy, num_values, num_unique_values, max, min, top1, top1_prob, top2, top2_prob, best_codec\n'
	stat_file = open(os.path.join(args.directory, 'csf_stats.csv'), 'wt')
	stat_file.write(stat_header)

	for data_file, dim in data_dim_pairs:
		csf_file = os.path.join(args.directory, f'csf_{dim:d}.csf')
		key_file = os.path.join(args.directory, f'dim_{dim:d}.keys')
		bf_file = os.path.join(args.directory, f'dim_{dim:d}.bfilter')
		if not os.path.isfile(key_file):
			print(f'Error: file {key_file} does not exist, cannot construct CSF for dimension {dim:d}.')
			sys.exit()

		best_raw_size = float('inf')
		best_file_size = float('inf')
		best_codec = None

		for codec in args.codecs:
			extra_flags = ['-C', codec]
			if args.ll_huffman_limit and codec == 'LLHUFFMAN':
				extra_flags += ['-l', str(args.ll_huffman_limit)]

			cmd = csf_utility_cmd(key_file, data_file, csf_file, extra_flags)
			proc = subprocess.run(cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
			if args.verbose >= 3:
				print(cmd)
				print(proc.stdout.decode('utf-8').strip())
				print(proc.stderr.decode('utf-8').strip())
			csf_bits = parse_csf_size(proc.stdout.decode('utf-8'))

			cmd = wc_utility_cmd(csf_file)
			proc = subprocess.run(cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
			if args.verbose >= 3:
				print(cmd)
				print(proc.stdout.decode('utf-8').strip())
				print(proc.stderr.decode('utf-8').strip())
			wc_bits = 8 * parse_wc_size(proc.stdout.decode('utf-8'))

			if args.verbose >= 2:
				print(f'{codec} codec on dimension {dim:d}: {csf_bits/8.0 * 1.0 / 1000.0:.2f} kB, {wc_bits/8.0 * 1.0 / 1000.0:.2f} kB')

			if csf_bits < best_raw_size:
				best_raw_size = csf_bits
				best_file_size = wc_bits
				best_codec = codec

		# Now consolidate stats into stat file
		# If bloom filter exists, then include the size of the bloom filter
		bloom_file_bits = 0
		if bf_file is not None and os.path.isfile(bf_file):
			cmd = wc_utility_cmd(bf_file)
			proc = subprocess.run(cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
			bloom_file_bits = 8 * parse_wc_size(proc.stdout.decode('utf-8'))
			if args.verbose >= 2:
				print(f'Dimension {dim:d} includes a bloom filter ({bloom_file_bits/8.0 * 1.0 / 1000.0:.2f} kB).')

		# preprocess_stats: 'dimension, entropy, num_values, max, min, top1, top1_prob, top2, top2_prob'
		num_values, entropy, num_unique_values, mx, mn, top1, top1_prob, top2, top2_prob, bloom_size_bits = preprocess_stat_dict[dim].split(',')

		if args.verbose >= 2:
			print(f'\tBloom filters: ({int(bloom_size_bits)/8.0 * 1.0 / 1000.0:.2f} kB, {bloom_file_bits/8.0 * 1.0 / 1000.0:.2f} kB with overhead')
			print(f'\tCSFs: ({best_raw_size/8.0 * 1.0 / 1000.0:.2f} kB, {best_file_size/8.0 * 1.0 / 1000.0:.2f} kB with overhead)')

		bits_per_key = (best_raw_size + int(bloom_size_bits)) / int(num_values)
		bits_per_key_with_overhead = (bloom_file_bits + best_file_size) / int(num_values)

		# dimension, csf_size_bits, csf_file_size_bits, bloom_size_bits, bloom_file_size_bits,
		stat_file.write(f'{dim:d},{best_raw_size:d},{best_file_size:d},{bloom_size_bits},{bloom_file_bits:d},')
		# bits_per_key, bits_per_key_with_overhead, entropy,
		stat_file.write(f'{bits_per_key:.4f},{bits_per_key_with_overhead:.4f},{entropy},')
		# num_values, num_unique_values, max, min, top1,
		stat_file.write(f'{num_values},{num_unique_values},{mn},{mx},')
		# top1_prob, top2, top2_prob, best_codec\n'
		stat_file.write(f'{top1_prob},{top2},{top2_prob},{best_codec}')
		stat_file.write('\n')


		if args.verbose >= 1:
			print(f'{best_codec}, {dim:d}, {entropy}, {bits_per_key:.4f}, {bits_per_key_with_overhead:.4f}')


	stat_file.close()
