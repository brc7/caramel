import argparse
import numpy as np
import pathlib
import sys
import os
from pybloom_live import BloomFilter

def generate_data(dataset, dimension, outpath, verbose = False):
	# dataset: integer array (N x dim).
	# dimension: dimension of the array to dump to file.
	# outpath: string. Little-endian binary long arrays will be 
	#    written to filename+"_dimension.bin"
	# statfile: file handle or None. Location to dump the csv string
	#    "dimension, H0_entropy, num_unique, max, min, top1, top2, top3, top4"
	# verbose: integer >= 0. If 0, no debug information will print.
	output_filename = outpath+f"_{dimension:d}.bin"
	with open(output_filename, 'wb') as f:
		values = dataset[:,dimension].astype('>u8')
		f.write(values.tobytes())
		if verbose:
			print("Dimension %d written in big-endian to %s." % (dimension, output_filename))


def generate_keys(dataset, filename):
	# Dumps newline-separated strings "0" - "num_data-1" to filename.
	N, _ = dataset.shape
	with open(filename, 'wt') as f:
		for n in range(N):
			f.write(f"{n:d}")
			if (n < N-1):
				f.write("\n")


def calculate_stats(x):
	# Returns a string containing comma-separated values:
	# (for 1-d input integer array x)
	# [empirical_entropy, num_unique_values, max_value, min_value,
	# top_1_value, top_1_value_fraction, top_2_value, top_2_value_fraction]
	unique_values, unique_counts = np.unique(x, return_counts=True)
	num_entries = np.sum(unique_counts)

	sorted_indices = unique_counts.argsort()
	sorted_values = unique_values[sorted_indices[::-1]]
	sorted_counts = unique_counts[sorted_indices[::-1]]
	sorted_probs = sorted_counts / num_entries

	empirical_entropy = -1 * np.sum(sorted_probs * np.log2(sorted_probs))
	num_unique_values = len(sorted_values)
	max_value = np.max(sorted_values)
	min_value = np.min(sorted_values)

	if num_unique_values > 1:
		topk_string = ','.join([f'{sorted_values[i]:d},{sorted_probs[i]:.4f}' for i in range(2)])
	else:
		topk_string = f'{sorted_values[0]:d},{sorted_probs[1]:.4f},-1,-1'
	return f'{empirical_entropy:.4f},{num_unique_values:d},{max_value:d},{min_value:d},' + topk_string


def calculate_e0(unique_values, unique_counts):
	num_entries = np.sum(unique_counts)
	unique_probs = unique_counts / num_entries
	alpha = np.max(unique_probs)  # highest probability value
	delta_3 = 1.089  # from XORSAT bounds
	return 1.44/(np.log(2) * delta_3) * (1 - alpha)/alpha


def generate_keys_and_values_for_bcsf(matrix, dimension, outdir, verbose=False):
	# matrix: integer array (N x dim)
	# dimension: column of that matrix to dump to file
	# outdir: String. Directory to write files to. Will write one keys file and one values file
	# verbose: bool flag for extra info
	N, _ = matrix.shape
	values = matrix[:,dimension].astype('>u8')
	keys_filename = outdir + f"/dim_{dimension:d}.keys"
	values_filename = outdir + f"/dim_{dimension:d}.bin"
	bloom_filter_filename = outdir + f"/dim_{dimension:d}.bfilter"
	with open(keys_filename, 'wt') as keys_file, open(values_filename, 'wb') as values_file:

		unique_values, unique_counts = np.unique(values, return_counts=True)
		max_idx = np.argmax(unique_counts)
		most_common_value = unique_values[max_idx]
		length_of_C = len(np.where(values != most_common_value)[0])
		if verbose:
			print(f"{100 * (1 - length_of_C/N):.1f}% of values are {most_common_value} for dimension {dimension}.")

		error_rate = calculate_e0(unique_values, unique_counts)
		desired_length = 0
		if verbose:
			print(f"Computed epsilon value {error_rate:.3f} for dimension {dimension}.")

		if error_rate < 1: # use bloom filter
			# The BloomFilter code uses a nonstandard "capacity" parameter. This computes the
			# capacity required for the BloomFilter implementation to achieve the desired length (in bits).
			# They use: capacity = ln(2)^2 / |ln(error)| * length_in_bits
			# We need: length_in_bits = log2(e) * num_keys * log2(1 / error)
			desired_length = np.log2(np.exp(1.0)) * length_of_C * np.log2(1.0/error_rate)
			required_capacity = desired_length * np.log(2)**2 / np.abs(np.log(error_rate))

			if verbose:
				print(f"Using BloomFilter for dimension {dimension} with size {int(desired_length)} bits and error {error_rate:.3f}.")

			bf = BloomFilter(capacity=int(required_capacity), error_rate=error_rate) 
			for key, value in enumerate(values):
				if value != most_common_value:
					bf.add(key) # add all keys to bf that do not correspond to the most common element

			new_values = []
			keys_to_write = []
			for key, value in enumerate(values):
				if key in bf: # write all (key, value) pairs that the bf claims are in the csf
					new_values.append(value)
					keys_to_write.append(key)

			if verbose:
				print(f"BloomFilter reduced CSF input size from {len(values)} to {len(new_values)} at a cost of {int(desired_length)} extra bits.")

			values_to_write = np.array(new_values)
			values_to_write = values_to_write.astype('>u8')
			with open(bloom_filter_filename, 'wb') as bloom_filter_file:
				bf.tofile(bloom_filter_file)

		else:  # don't use bloom filter
			keys_to_write = range(N)
			values_to_write = values.astype('>u8')

		# write the selected keys and values to files
		for key in keys_to_write:
			keys_file.write(f"{key:d}")
			if (key < N-1):
				keys_file.write("\n")

		values_file.write(values_to_write.tobytes())
		if verbose:
			print(f"Dimension {dimension} written in big-endian. Keys: {keys_filename}, Values: {values_filename}.")
		return int(desired_length)
	return 0


if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='Preprocess data for use with the CSF tool.')
	parser.add_argument('filename', metavar='input_filename', type=str, help='Input file (npy format).')
	parser.add_argument('outdir', metavar='output_directory', type=str, help='Output directory for dumped tokens.')
	parser.add_argument('-v', '--verbose', action='store_true', help='Print verbose output logs.')
	parser.add_argument('-bf', '--use_bloom_filter', action='store_true', help='Use a BloomFilter with the CSF.')

	args = parser.parse_args()

	matrix = np.load(args.filename)
	if len(matrix.shape) == 1:
		matrix = matrix.reshape([-1,1])
	num_data, num_dimensions = matrix.shape
	if args.verbose:
		print(f"Loaded matrix with {num_data:d} rows and {num_dimensions:d} columns.")

	pathlib.Path(args.outdir).mkdir(parents=True, exist_ok=True)

	stat_header = 'dimension, num_values, entropy, num_unique_values, max, min, top1, top1_prob, top2, top2_prob, bloom_size_bits\n'
	with open(os.path.join(args.outdir, 'csf_preprocess_stats.csv'), 'wt') as stat_file:
		stat_file.write(stat_header)
		for dim in range(num_dimensions):
			if args.use_bloom_filter:
				filter_size = generate_keys_and_values_for_bcsf(matrix, dim, args.outdir, verbose=args.verbose)
			else:
				generate_data(matrix, dim, args.outdir + "/dim", verbose=args.verbose)
				generate_keys(matrix, args.outdir + f"/dim_{dim}.keys")
				filter_size = 0

			stat_string = calculate_stats(matrix[:,dim])
			stat_file.write(f"{dim},{num_data},{stat_string},{filter_size}\n")

	# DUMPED FILENAMES
	# dim_{dim}.bin for each dim
	# dim_{dim}.keys for each dim #TODO: reuse a single keys.keys when we decide not to use bloom filter
	# dim_{dim}.bfilter for each dim



