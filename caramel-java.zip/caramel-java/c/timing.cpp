#include <iostream>
#include <fcntl.h>
#include <string>
#include <numeric>
#include <vector>
#include <random>
#include <algorithm>
#include <math.h>
#include <chrono>
#include <unordered_map>
#include "csf3.h"

using namespace std;

class InputParser{
    public:
        InputParser (int &argc, char **argv) {
            for (int i=1; i < argc; ++i)
                this->tokens.push_back(std::string(argv[i]));
        }

        const std::string& getCmdOption(const std::string &option) const {
            std::vector<std::string>::const_iterator itr;
            itr =  std::find(this->tokens.begin(), this->tokens.end(), option);
            if (itr != this->tokens.end() && ++itr != this->tokens.end()) {
                return *itr;
            }
            static const std::string empty_string("");
            return empty_string;
        }

        bool cmdOptionExists(const std::string &option) const {
            return std::find(this->tokens.begin(), this->tokens.end(), option)
                   != this->tokens.end();
        }
    private:
        std::vector <std::string> tokens;
};

vector<string> generateQueryKeys(uint64_t numKeys, uint64_t numQueries) {
    std::random_device rd; // obtain a random number from hardware
    std::mt19937 gen(rd()); // seed the generator
    std::uniform_int_distribution<> distr(0, numKeys); // define the range

    vector<uint64_t> query_keys(numQueries); 
    for(int n = 0; n < numQueries; n++)
        query_keys.push_back(distr(gen));

    vector<string> query_keys_strings(numQueries); 
    for (auto key : query_keys) {
        query_keys_strings.push_back(to_string(key));
    }
    
    return query_keys_strings;
}

vector<chrono::duration<double, std::milli>> testCsfTimes(const vector<string> &query_keys, const string &directory, bool verbose) {
    // read CSF files into csf_array
    int i = 0;
    vector<csf_t *> csf_array;
    while (true) {
        string csf_filename_string = (string)(directory + "/csf" + to_string(i));
        if (verbose) cout << "FOUND CSF FILE " << csf_filename_string << endl;
        const char * csf_filename = csf_filename_string.c_str();
        int fd = open(csf_filename, O_RDONLY);
        if (fd == -1) {
            if (verbose) cout << "Stopped reading csfs at csf number " << i << endl;
            break;
        }
        csf_t* csf = load_csf(fd);
        csf_array.push_back(csf);
        i++;
    }

    if (csf_array.size() == 0) {
        cout << "Error reading CSF files. CSF files should be named csf0, csf1, ..., csfm" << endl;
        exit(1);
    }

    vector<chrono::duration<double, std::milli>> timings;
    for (uint64_t i = 0; i < query_keys.size(); i++) {
        auto start = std::chrono::high_resolution_clock::now();
        for (csf_t* csf : csf_array) {
            string query_key = query_keys[i];
            int64_t val = csf3_get_byte_array(csf_array[0], (char *)query_key.c_str(), query_key.length());
        }
        chrono::duration<double, std::milli> duration = std::chrono::high_resolution_clock::now() - start;
        timings.push_back(duration);
    }
    return timings;
}

vector<chrono::duration<double, std::milli>> testHashTableTimes(uint64_t numKeys, const vector<string> &query_keys) {
    // construct hashmap from each of the keys to a random vector of size 256 (arbitrary number)
    unordered_map<string, vector<uint64_t>> map;
    for (int i = 0; i < numKeys; i++) {
        vector<uint64_t> vec(256);
        iota(begin(vec), end(vec), 0);
        map[to_string(i)] = vec;
    }

    vector<chrono::duration<double, std::milli>> timings;
    for (string query_key : query_keys) {
        auto start = std::chrono::high_resolution_clock::now();
        vector<uint64_t> vals = map[query_key];
        chrono::duration<double, std::milli> duration = std::chrono::high_resolution_clock::now() - start;
        timings.push_back(duration);
    } 
    return timings;
}


void printTimings(vector<chrono::duration<double, std::milli>> timings) {
    sort(timings.begin(), timings.end());
    cout << "    Median: " << timings[floor(timings.size() * 0.5)].count() << "s\n";
    cout << "    P99: " << timings[floor(timings.size() * 0.99)].count() << "s\n";
    cout << "    P99.9: " << timings[floor(timings.size() * 0.999)].count() << "s\n";
    cout << "    P99.99: " << timings[floor(timings.size() * 0.9999)].count() << "s\n";
}


int main(int argc, char *argv[]) {
    InputParser input(argc, argv);

    bool verbose = false;
    if (input.cmdOptionExists("-v")) verbose = true;

    const std::string &directory = input.getCmdOption("-d");
    if (directory.empty()) {
        cout << "Error parsing command directory argument." << endl;
        exit(1);
    }

    const std::string &numKeysString = input.getCmdOption("-numKeys");
    if (numKeysString.empty()) {
        cout << "Error parsing command numKeys argument." << endl;
        exit(1);
    }
    uint64_t numKeys = stoull(numKeysString);

    uint64_t num_queries = 20000;
    vector<string> query_keys = generateQueryKeys(numKeys, num_queries);

    if(input.cmdOptionExists("-csf")) {
        vector<chrono::duration<double, std::milli>> timings = testCsfTimes(query_keys, directory, verbose);
        cout << "Printing time results for " << num_queries << " queries on CSF Array:" << endl;
        printTimings(timings);
    }

    if(input.cmdOptionExists("-hashtable")) {
        vector<chrono::duration<double, std::milli>> timings = testHashTableTimes(numKeys, query_keys);
        cout << "Printing time results for " << num_queries << " queries on HashTable of size " << numKeys << ":" << endl;
        printTimings(timings);
    }

    return 0;
}