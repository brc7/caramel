gcc -c -Wall -O3 -Wno-unused-result csf3.c csf.c spooky.c
g++ -c timing.cpp
g++ -o timing csf3.o csf.o spooky.o timing.o