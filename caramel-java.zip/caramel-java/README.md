# proto-caramel


This is a prototype for CARAMEL (Compressed Array Representation And More Efficient Lookups).


# Installing the Java toolchain

For now, we use the Sux4J compressed static function library, which builds with Maven and is compatible with most Java versions. This has been tested to work with Maven 3.8.5 and JDK 17.0.2, but will likely work with other configurations.

## Linux and MacOS

Installation with Linux is fairly straightforward. We just need to download prebuilt binaries for the JDK and Maven. It is possible to perform a local installation on Linux that does not require administrator privileges by installing each of the components to a local directory and modifying the corresponding path variables.

#### 1. Install the JDK
To begin with, obtain a version of the JDK from [Oracle's official repository](https://www.oracle.com/java/technologies/downloads/). Unpack and install the JDK at a location of your choice.

**Note about JDK and JRE**: MacOS and many Linux distros come with Java installed, but this usualy only includes the Java Runtime Environment (JRE) to run Java programs. To develop programs, we need the Java Development Kit (JDK). If you have the JRE and not the JDK, Maven will fail to build your program.


**Note for M1/Intel Macs** If you have an Intel-based Mac, then you want the `x64` JDK download. If you have an M1-based Mac, the `ARM 64` version is probably correct (though I cannot verify this, as I use the i5-based 2015 Macbook Pro).


#### 2. Install Maven

To install Maven, download Maven from [this page](https://maven.apache.org/download.cgi) and follow the instructions [here](https://maven.apache.org/install.html). In more detail, you will download a tarball archive, copy the tarball to the location you wish to install Maven, and run the following:

```
tar -xzvf apache-maven-3.8.5-bin.tar.gz
```

To confirm that you have downloaded a version that is compatible with your system, you can run the following to test the installation. Since we do not have a Maven project, this should throw a build error.

```
apache-maven-3.8.5/bin/mvn
```

#### 3. Path Variables

Maven uses the `PATH` and `JAVA_HOME` shell variables to locate and run the correct JDK version. To run without issues, you will want to add the following to your `.bashrc` or `.bash_profile` file (or equivalent, depending on your preferred shell).

```
export PATH="/path/to/apache-maven-3.8.5/bin:$PATH"
export PATH="/path/to/jdk-17.0.2/bin:$PATH"
export JAVA_HOME="/path/to/jdk-17.0.2"
```

**MacOS Note 1: Bin location** The path to Java might be slightly different from what you expect on MacOS. On Linux and most other systems, the bin location is `jdk-xx.x.x/bin`, but on MacOS these tools are located under `jdk-xx.xx.x/Contents/Home/bin` instead. Similarly, the `JAVA_HOME` variable should be set to `jdk-xx.xx.x/Contents/Home` instead.

**MacOS Note 2: Using `zsh`** In 2019, MacOS switched from using bash to zsh by default. You can detect which shell is your default using `$SHELL`. If you're using zsh, then you will need to add the PATH changes to `.zshrc` or `.zsh_profile` instead of `.bashrc` or `.bash_profile`.

**MacOS Note 3: Use `.bash_profile`** On MacOS, the PATH variables should be added to `.bash_profile` (or `.zsh_profile`) rather than to `.bashrc`. This is because the default Terminal app starts a login shell on MacOS, and `.bash_profile` runs for login shells while `.bashrc` runs for non-login shells. On Linux, non-login shells are opened by default, meaning that `.bashrc` is the correct choice.

## Windows

I have not tested a Windows installation, but you should be able to follow the Windows-specific installation instructions for Maven and the JDK.

# Building the CSF Tool in Java

Once you have installed all of the required Java toolchain items, the following build commands should successfully build the tool in `./java-caramel/target/`.

```
cd java-caramel
mvn package
```

This will create a bundled jar file (with all dependencies) at `./java-caramel/target/java-caramel-1.0-SNAPSHOT.jar`, as well as a bunch of class files in the subdirectories of `./java-caramel/target`. We will only need the bundled jar to run the experiments.

If you want to *manually* call the tool, then the following command creates a compressed static function.

```
java -cp ./java-caramel/target/java-caramel-1.0-SNAPSHOT.jar com.randorithms.app.App -v values.bin csf_file keys.txt
```

Here, `values.bin` is a list of N integers, stored as a contiguous binary array of unsigned long (8-byte) integers in big-endian format, `keys.txt` is a newline-separated list of N strings (one for each value) and `csf_file` is the path where we wish to store the compressed static function.

# Running the experiments in Python

You could use the Java tool to manually construct each CSF (for each dimension) independently, but that would take a long time. Instead, we suggest using the Python tools to run experiments. The only dependencies are Python 3 and a reasonably modern numpy installation.

There are three Python modules:
- preprocess: Takes a `.npy` file containing an (N by d) array and outputs Java-readable value files named `dim_${d}.bin` (one for each dimension d of the array) and a text file `keys.keys` to a directory.
- construct: Takes the directory created by the preprocessing tool, constructs a CSF for each dimension and writes a file `csf_statistics.csv` to the directory.
- plots: Takes the `csf_statistics.csv` file and generates entropy plots showing overhead.

Each module has a main function that can be invoked as-is to perform the function of the tool. 

For example, let's generate some test data (`test.npy`) using `generate_test_data.py`.
```
python3 generate_test_data.py
```

Now we can run:

```
python3 preprocess.py test.npy test_directory
python3 construct.py test_directory
python3 plot.py test_directory/csf_stats.csv
```




**Note:** All of the tools should be run from the top-level project directory, because I have used relative paths to call the Java programs. 



# Baselines 

For our baselines, we use slightly different input formats. For Succinct, we concatenate the keys with the values in the table (the array) and we apply Succinct compression to the entire thing. For MPH table, we turn the table into a TSV dataset of key (tab) [comma-separated list of values]. We parse the comma separated values as the smallest possible integer, though in some cases (genomics data), Java's integer reader overflows.

These baselines can be run by constructing the corresponding java library and running the following commands to construct the table.
```
java -cp target/succinct-core-0.1.8-jar-with-dependencies.jar edu.berkeley.cs.succinct.examples.Construct input_file_concatenated_with_keys output_file.succinct 'binary-file'

java --add-opens java.base/java.lang=ALL-UNNAMED --add-opens java.base/java.io=ALL-UNNAMED --add-opens java.base/java.util=ALL-UNNAMED --add-opens java.base/java.base=ALL-UNNAMED  -cp target/mph-table-1.0.6-SNAPSHOT.jar com.indeed.mph.TableWriter --keySerializer .SmartIntegerSerializer --valueSerializer '.SmartListSerializer(.SmartLongSerializer)' table.mph table.tsv
```
