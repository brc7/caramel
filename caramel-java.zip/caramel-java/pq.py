#!/usr/bin/env python
# coding: utf-8

from collections import defaultdict
import argparse
import math
import numpy as np
import faiss # install as pip install faiss-cpu if it doesnt work


class FaissKMeans:
    def __init__(self, n_clusters=8, n_init=10, max_iter=300):
        self.n_clusters = n_clusters
        self.n_init = n_init
        self.max_iter = max_iter
        self.kmeans = None
        self.cluster_centers_ = None
        self.inertia_ = None

    def fit(self, X):
        self.kmeans = faiss.Kmeans(d=X.shape[1],
                                   k=self.n_clusters,
                                   niter=self.max_iter,
                                   nredo=self.n_init)
        self.kmeans.train(X.astype(np.float32))
        self.cluster_centers_ = self.kmeans.centroids
        self.inertia_ = self.kmeans.obj[-1]

    def predict(self, X):
        return self.kmeans.index.search(X.astype(np.float32), 1)[1]


def product_quantization(embeddings, M, k, verbose=False):
    """
    embeddings: embedding vectors
    M: size of vector subsections
    k: number of clusters for k-means clustering

    Runs product quantization on the embeddings.
    Returns each embedding as an array of integers, each representing the id of a centroid in that region
    """
    num_subsections = math.ceil(len(embeddings[0]) / M)
    if verbose:
        print(
            f"Splitting {len(embeddings)} embeddings of size {len(embeddings[0])} into {num_subsections} subsections of size {M}")

    print(f"Performing k means search with k = {k}")
    embeddings_as_centroid_ids = [[] for _ in range(len(embeddings))]

    for section_index in range(num_subsections):
        section = embeddings[:,section_index:section_index+M]

        if verbose:
            print(f"Starting k means for section {section_index} on M={M}")

        kmeans = FaissKMeans(n_clusters=k)
        kmeans.fit(section)
        labels = kmeans.predict(section)
        for i in range(len(labels)):
            centroid_id = labels[i]
            embeddings_as_centroid_ids[i].append(centroid_id[0])

    return embeddings_as_centroid_ids


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('input_file', action="store", metavar="<input_file>",
                        help="Vectors to quantize. Supports 2d input in the form of a .npy file")
    parser.add_argument('-v', '--verbose', action='store_true', help='Print verbose output logs.')
    parser.add_argument("M", action="store", metavar="<M>",
                        help="Desired M for subvector sizes. A good number is between 2 and 4 to retain >80% KNN recall")
    parser.add_argument("k", action="store", metavar="<k>", default=256,
                        help="Desired k for k-means.")
    args = parser.parse_args()

    embeddings = np.load(args.input_file)
    quantized = product_quantization(embeddings, k=int(args.k), M=int(args.M), verbose=True)

    np.save(f'quantized_embeddings_M_{args.M}.txt', np.array(quantized).astype(int))
