import argparse
import numpy as np
import string
import random
import os


class count_sketch():
    def __init__(self, n_rows, n_cols, salt_len = 4):
        # n_rows = O(log N/delta)
        # n_cols = O(1/epsilon)
        self.sketch = np.zeros((n_rows, n_cols), dtype=int)
        self.r = n_rows
        self.w = n_cols
        self.salt_len = salt_len
        self.hash_salts = [''.join(random.choice(string.printable)
                           for _ in range(salt_len))
                           for _ in range(n_rows)]

    def add(self, item, count=1):
        allhashes = [hash(str(item)+salt) for salt in self.hash_salts]
        for idx, hashval in enumerate(allhashes):
            self.sketch[idx, hashval % self.w] += count

    def query(self, item):
        allhashes = [hash(str(item)+salt) for salt in self.hash_salts]
        allvalues = []
        for idx, hashval in enumerate(allhashes):
            allvalues.append(self.sketch[idx, hashval % self.w])
        return np.min(allvalues)

    def entropy(self):
        values, counts = np.unique(self.sketch, return_counts=True)
        num_entries = np.sum(counts)
        probs = counts / num_entries
        return -1 * np.sum(probs * np.log2(probs))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Create a count sketch and dump to a .npy file.')
    parser.add_argument('infile', metavar='CSV of (item, count) pairs', type=str, help='CSV file containing newline-separated \'item,count\' entries.')
    parser.add_argument('outfile', metavar='NPY output file', type=str, help='Location to write npy file output.')
    parser.add_argument('-r', '--rows', type=int, default=10, help='Number of rows in the count sketch. Set proportional to log(N/delta).')
    parser.add_argument('-w', '--width', type=int, default=10000, help='Number of columns in the count sketch. Set proportional to 1/epsilon, where the additive error is epsilon * total_count.')
    parser.add_argument('-v', '--verbose', action='count', default=0, help='Verbosity level (e.g. vv = level 2). 0 = no output, 1 = CSV of best codecs, 2 = CSV of all codecs, 3 = show java tool output.')
    args = parser.parse_args()

    if not os.path.isfile(args.infile):
        print(f"Error: {args.infile} is not a valid file.")
        sys.exit()

    S = count_sketch(args.rows, args.width)
    with open(args.infile, 'rt') as f:
        for line in f:
            item, item_count = line.split(',')
            item_count = int(item_count)
            S.add(item, count=item_count)
    
    error = []
    with open(args.infile, 'rt') as f:
        for line in f:
            item, item_count = line.split(',')
            predicted_count = S.query(item)
            error.append(np.abs(int(item_count) - predicted_count))
    print(S.sketch)
    print(f'Mean absolute error: {np.mean(error):.2f}')
    print(f'Stddev absolute error: {np.std(error):.2f}')
    print(f'Sketch value entropy: {S.entropy():.4f}')

    np.save(args.outfile, S.sketch.flatten())
