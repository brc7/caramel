import numpy as np
import sys
# Converts a npy file and a set of keys to indeed MPH ingestion format
# If no keys provided, then we use strings from '0' to 'N'

# Call: Python3 convert_to_csv.py [input npy file] [output CSV file]
if len(sys.argv) < 3:
    print("Python3 convert_to_csv.py [input npy file] [output CSV file]")
    sys.exit()

import pandas as pd 
X = np.load(sys.argv[1])
df = pd.DataFrame(X)
df = df.astype(int)
df.to_csv(sys.argv[2])