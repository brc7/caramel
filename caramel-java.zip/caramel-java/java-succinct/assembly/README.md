# Succinct-Assembly

This is an assembly module for Succinct.

It creates a single jar file that includes all needed dependencies for the 
project.
