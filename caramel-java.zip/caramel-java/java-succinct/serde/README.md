# Succinct-SerDe

Serialization/Deserialization module for Succinct. This module provides serialization and deserialization logic for different semi-structured and structured representations of data on top of a flat file representation of data.