package edu.berkeley.cs.succinct;

import junit.framework.TestCase;

public class PrimitiveSerializerTest extends TestCase {

  public void testSerialize() throws Exception {

  }

  public void testSerialize1() throws Exception {

  }

  public void testSerialize2() throws Exception {

  }

  public void testSerialize3() throws Exception {

  }

  public void testSerialize4() throws Exception {

  }

  public void testSerialize5() throws Exception {

  }

  public void testSerialize6() throws Exception {

  }

  public void testSerialize7() throws Exception {

  }

  public void testSerialize8() throws Exception {

  }

  public void testSerialize9() throws Exception {

  }
}
