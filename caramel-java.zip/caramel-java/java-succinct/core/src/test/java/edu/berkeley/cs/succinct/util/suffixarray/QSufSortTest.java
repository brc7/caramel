package edu.berkeley.cs.succinct.util.suffixarray;

import edu.berkeley.cs.succinct.util.IOUtils;
import edu.berkeley.cs.succinct.util.Source;
import edu.berkeley.cs.succinct.util.SuccinctConstants;
import junit.framework.TestCase;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.HashSet;

public class QSufSortTest extends TestCase {

  private String testFileRaw = this.getClass().getResource("/test_file").getFile();
  private String testFileSA = this.getClass().getResource("/test_file.sa").getFile();
  private String testFileISA = this.getClass().getResource("/test_file.isa").getFile();
  private QSufSort instance;
  private byte[] data;
  private int n;

  /**
   * Set up test.
   *
   * @throws Exception
   */
  public void setUp() throws Exception {
    super.setUp();
    instance = new QSufSort();
    File inputFile = new File(testFileRaw);

    data = new byte[(int) inputFile.length()];

    DataInputStream dis = new DataInputStream(new FileInputStream(inputFile));
    dis.readFully(data);
    n = data.length + 1;

    instance.buildSuffixArray(new Source() {
      @Override public int length() {
        return data.length;
      }

      @Override public int get(int i) {
        return data[i];
      }
    });
  }

  public void testGetAlphabet() {
    int[] alphabet = instance.getAlphabet();

    HashSet<Integer> set = new HashSet<>();
    for (byte d : data) {
      set.add((int) d);
    }
    set.add(SuccinctConstants.EOF);
    int[] expectedAlphabet = new int[set.size()];
    int i = 0;
    for (Integer value : set) {
      expectedAlphabet[i++] = value;
    }
    Arrays.sort(expectedAlphabet);

    assertTrue(Arrays.equals(expectedAlphabet, alphabet));
  }

  /**
   * Test method: int[] getSA()
   *
   * @throws Exception
   */
  public void testGetSA() throws Exception {
    int[] SA = instance.getSA();

    long sum = 0;
    DataInputStream dIS = new DataInputStream(new FileInputStream(new File(testFileSA)));
    int[] testSA = IOUtils.readArray(dIS);
    dIS.close();

    for (int i = 0; i < n; i++) {
      assertEquals(testSA[i], SA[i]);
      sum += SA[i];
      sum %= n;
    }
    assertEquals(0L, sum);
  }

  /**
   * Test method: int[] getSA()
   *
   * @throws Exception
   */
  public void testGetISA() throws Exception {
    int[] ISA = instance.getISA();

    long sum = 0;
    DataInputStream dIS = new DataInputStream(new FileInputStream(new File(testFileISA)));
    int[] testISA = IOUtils.readArray(dIS);
    dIS.close();
    for (int i = 0; i < n; i++) {
      assertEquals(testISA[i], ISA[i]);
      sum += ISA[i];
      sum %= n;
    }
    assertEquals(0L, sum);
  }
}
