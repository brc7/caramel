package edu.berkeley.cs.succinct.util.buffer.serops;

import junit.framework.TestCase;

public class WaveletTreeOpsTest extends TestCase {

  /**
   * Set up test.
   *
   * @throws Exception
   */
  public void setUp() throws Exception {
    super.setUp();
  }

  /**
   * Test method: long getValue()
   *
   * @throws Exception
   */
  public void testGetValue() throws Exception {

    // TODO: Add test
  }
}
