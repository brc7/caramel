package edu.berkeley.cs.succinct.regex.parser;

public enum RegExRepeatType {
  ZeroOrMore,
  OneOrMore,
  MinToMax
}
