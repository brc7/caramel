package edu.berkeley.cs.succinct;

public enum StorageMode {
  MEMORY_ONLY,
  MEMORY_MAPPED
}
