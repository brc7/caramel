package edu.berkeley.cs.succinct.regex.parser;

public class RegExBlank extends RegEx {

  /**
   * Constructor to initialize RegExBlank.
   */
  public RegExBlank() {
    super(RegExType.Blank);
  }

}
