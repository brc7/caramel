package edu.berkeley.cs.succinct.util;

public interface Source {
  int length();

  int get(int i);
}
