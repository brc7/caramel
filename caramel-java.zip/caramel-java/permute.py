import argparse
import numpy as np
import sys
import time

from collections import defaultdict
import functools
import bisect

'''
Problem description: 

Given an integer matrix A in Z^(NxM) with N rows and M columns, 
suppose that the entries of the matrix can be permuted along each
row without affecting the validity of the representation. For example,
the following rows are equivalent:
[1, 2, 4, 3, 0]
[0, 4, 2, 3, 1]
Such a situation can arise in product recommendation, where each
row is a set of pre-computed product IDs, or in genomics, where
each row is a set of minhash values. The order of items within a
row does not matter.

Also suppose that the elements in each row are distinct (no duplicates). If this is not
the case, then we can de-duplicate without changing the optimal solution
(just map each duplicate to a unique value)

The task is to find the permutation with the lowest average column-wise entropy.

Algorithm:

1. Initialize table T from value {v} -> row list [r1, r2, ...]
2. Initialize table E from column {c} -> ineligible rows [r1, r2, ...]
3. While there are still eligible rows (while min_c |E[c]| < M):
4. Sort T by |T[v]| in descending order
5. (c^*, v^*) = (None, None) and Smax = 0 (max size of possible entropy-block)
6. for i = 0 to len(T):
    if Smax >= |T[vi]|:
        break
    c' = argmax_c |T[vi] setminus E[c]|
    (i.e. the intersection of rows containing this value with eligiable rows)
    if |T[vi] setminus E[i]| > Smax:
        Smax = |T[vi] setminux E[i]|
        c^*, v^* = c', vi
7. For r in eligible rows (T[vi] setminus E[i])
    find v^* at location c in A[r]
    swap A[c] (containing v^*) and A[c^*] (containing whatever)
    pop r from T[v^*]
    add r to E[c^*]
'''

def permute_entropy(data, max_iter=None, min_block_size=1, verbose=False):
    # data: NxM int array
    # max_iter: maximum number of permutation steps to take
    # min_block_size: minimum size of group to permute. If min_block_size
    # is 100, we will not consider swapping values unless we can group
    # at least 100 of the same value into a single row.
    num_rows = data.shape[0]
    num_cols = data.shape[1]

    values = set()
    row_lists = defaultdict(lambda: set())  # Table T in the algorithm.
    for row, row_contents in enumerate(data):
        if verbose and (row % 1000 == 0):
            print('.',end='')
            sys.stdout.flush()
        for value in row_contents:
            values.add(value)
            row_lists[value].add(row)
    if verbose:
        print('')

    ineligible_rows = [set() for _ in range(num_cols)]  # Table E in the algorithm.

    # Optimization: search columns starting with "most eligible"
    column_list = list(range(num_cols))
    column_key_fn = functools.cmp_to_key(lambda c1,c2: len(ineligible_rows[c1]) - len(ineligible_rows[c2]))
    column_list.sort(key=column_key_fn)

    # Optimization: Delete the tail, to speed up search / sorting later.
    values = list(values)
    values_key_fn = functools.cmp_to_key(lambda v1,v2: len(row_lists[v1]) - len(row_lists[v2]))
    values.sort(key=values_key_fn)
    for val_idx in range(len(values)):
        # Binary search would be better, but this only happens once.
        if len(row_lists[values[val_idx]]) >= min_block_size:
            break
    for val in values[:val_idx]:
        del row_lists[val]
    values = values[val_idx:]
    num_values = len(values)
    if verbose:
        print("Considering",num_values,"unique values.")

    # List of keys v for row_lists, sorted in order of len(T[v]).
    # Optimization: After the first sorting, sort based on max number of eligible rows
    # rather than just the number of available rows.
    values_max_eligible = {v : len(row_lists[v]) for v in values}
    values_key_fn = functools.cmp_to_key(lambda v1,v2: values_max_eligible[v1] - values_max_eligible[v2])

    for iteration in range(num_values):
        ti = time.time()
        if max_iter is not None and iteration >= max_iter:
            return data

        best_num_eligible = -1
        best_val = None
        best_val_idx = None
        best_col = None
        best_row_set = None

        # start with the value with highest known number of eligible rows.
        for val_idx in reversed(range(len(values))):
            t00 = time.time()
            val = values[val_idx]
            if best_num_eligible >= len(row_lists[val]):
                # Since row_lists are indexed in descending order of size,
                # if the current list offers fewer eligible values than the
                # best option so far, we can skip all remaining values.
                break
            value_max_eligible = 0
            for col in column_list:  # find argmax over columns.
                eligible_row_set = (row_lists[val] - ineligible_rows[col])
                value_max_eligible = max(value_max_eligible, len(eligible_row_set))
                if len(eligible_row_set) > best_num_eligible:
                    best_num_eligible = len(eligible_row_set)
                    best_row_set = eligible_row_set
                    best_val = val
                    best_val_idx = val_idx
                    best_col = col
                if len(eligible_row_set) == len(row_lists[val]):
                    # Short circuit the evaluation over columns since no other column will do better.
                    break
                if len(eligible_row_set) >= (num_rows - len(ineligible_rows[col])):
                    # Since column_list are indexed in descending order of size,
                    # if the current column offers fewer eligible values than the best
                    # option so far, we can skip all remaining columns.
                    break

            values_max_eligible[val] = value_max_eligible
            t01 = time.time()
            if verbose:
                print("\tTime for col argmax@val",val,":",t01-t00)
                print("\t\t",val,"available:",len(row_lists[val]),"max_eligible:",value_max_eligible,"fraction:",float(value_max_eligible)/len(row_lists[val]))

        if best_val is None:
            return data  # No values remaining in list.
       
        if verbose:
            print("\nChose:",best_val,"best_available:",len(row_lists[best_val]),"best_eligible:",best_num_eligible,"fraction:",float(best_num_eligible)/len(row_lists[best_val]))

        # For all rows in best_row_set, transfer best_val to location best_col.
        for row in best_row_set:
            # This is brute-force over columns, but it's not a bottleneck.
            initial_col = np.where(data[row,:] == best_val)[0]
            if len(initial_col) >= 1:
                initial_col = initial_col[0]
            else:  # This only occurs if best_val is not in the row, which should not happen.
                continue
            data[row, initial_col] = data[row, best_col]
            data[row, best_col] = best_val

        # Mark rows as ineligible if we have assigned them.
        ineligible_rows[best_col] = ineligible_rows[best_col].union(best_row_set)

        # Now delete best_row_set from row_lists[best_val]
        if len(best_row_set) == len(row_lists[best_val]):
            del row_lists[best_val]
            # Delete the value if we've re-sorted all the values.
            del values[best_val_idx]
        else:
            row_lists[best_val] = row_lists[best_val] - best_row_set

        # Maintain invariants.
        values.sort(key=values_key_fn)
        column_list.sort(key=column_key_fn)

        tf = time.time()
        if verbose:
            print("Iteration time:", tf - ti)
            sys.stdout.flush()

        if min_block_size is not None and best_num_eligible <= min_block_size:
            return data


def cantor_deduplicate(data):
    # De-duplicate data with Cantor's bijection.
    # Might overflow with large integers.
    data.sort(axis=1)
    # To biject from (value, duplicate_id) -> value
    # we need to count the number of running duplicates
    duplicate_ids = np.zeros_like(data)
    for dim in range(1, data.shape[1]):
        indicator = data[:,dim] == data[:,dim-1]
        duplicate_ids[:,dim] = indicator * (duplicate_ids[:,dim-1] + 1)
    # Return the bijection
    return duplicate_ids + (data + duplicate_ids + 1) * (data + duplicate_ids) // 2


def cantor_reduplicate(data):
    # Re-duplicate data with (inverse) Cantor's bijection.
    # https://en.wikipedia.org/wiki/Pairing_function#Cantor_pairing_function
    w = np.floor(0.5 * (np.sqrt(8*data + 1) - 1))
    t = (w*w + w) // 2
    duplicate_ids = data - t
    original_data = w - duplicate_ids
    return original_data.astype(data.dtype)


def detect_duplicates(data):
    # Complexity is O(Nd log d)
    for row in data:
        _, counts = np.unique(row, return_counts=True)
        if np.max(counts) > 1:
            return True
    return False


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Permute data to minimize entropy.')
    parser.add_argument('infile', metavar='input_filename', type=str, help='Input file (npy format).')
    parser.add_argument('outfile', metavar='output_filename', type=str, help='Output file (npy format).')
    parser.add_argument('-b', '--blocksize', type=int, default=100, help='Block size for permutation.')
    parser.add_argument('-m', '--max_iters', type=int, default=None, help='Maximum number of greedy iterations.')
    parser.add_argument('-v', '--verbose', action='store_true', help='Print verbose output logs.')

    args = parser.parse_args()

    matrix = np.load(args.infile)
    num_data, num_dimensions = matrix.shape
    if args.verbose:
        print(f"Loaded matrix with {num_data:d} rows and {num_dimensions:d} columns.")

    contains_duplicates = detect_duplicates(matrix)
    if contains_duplicates:
        if args.verbose:
            print("Detected duplicate entries - applying de-duplication.")
        matrix_biject = cantor_deduplicate(matrix)
        # Verify that the bijection didn't overflow
        matrix_orig = cantor_reduplicate(matrix_biject)
        if np.sum(matrix_orig - matrix) != 0:
            print("Bijection failed due to numerical overflow.")
            sys.exit()
        else:
            if args.verbose:
                print("Bijection successful and invertible.")


    matrix = permute_entropy(matrix, max_iter=args.max_iters, min_block_size=args.blocksize, verbose=args.verbose)

    if contains_duplicates:
        matrix = cantor_reduplicate(matrix)

    np.save(args.outfile, matrix)
