import numpy as np


N = 100_000
d = 20

X = np.random.geometric(p=0.5, size=(N, d))
np.save('test.npy', X)

